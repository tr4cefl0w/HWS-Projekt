#include <Windows.h>
#include <iostream>
#include <array>
#include "DMAHandler.h"


int main()
{
	auto target = DMAHandler(L"lsass.exe");

	if (!target.isInitialized())
		DebugBreak();

	if (!target.getPID())
		DebugBreak();

	
	printf("PID: 0x%X\n", target.getPID());

	printf("base: 0x%llX\n", target.getBaseAddress());

	/*auto res = target.read<std::array<char, 6>>(target.getBaseAddress() + 0x5380);

	printf("Password -> %s \n", res.data());*/

	DMAHandler::closeDMA();

	getchar();

	return 0;
}