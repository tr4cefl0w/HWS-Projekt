#include <iostream>
#include <string_view>

int main() {

	std::string password{};

	while (password != "Hello") {

		std::cout << "Enter password -> ";
		std::cin >> password;

	}

	std::cout << "Correct password";

	return EXIT_SUCCESS;

}

